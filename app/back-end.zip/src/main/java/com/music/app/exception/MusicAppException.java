package com.music.app.exception;
 
public class MusicAppException extends RuntimeException{
    public MusicAppException(String message) {
        super(message);
    }
}